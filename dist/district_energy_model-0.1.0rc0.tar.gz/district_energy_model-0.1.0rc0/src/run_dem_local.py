# -*- coding: utf-8 -*-
"""
Created on Wed Nov 26 10:15:29 2025

@author: UeliSchilt
"""

"""
For running DEM locally using the source code.
"""

from district_energy_model.run_dem import main

root_dir = '..'

if __name__ == "__main__":
    main(root_dir)
    
